package fr.dawan.projetLMT.enums;

public enum Level {
	BEGINNER,
	INTERMEDIATE,
	ADVANCED,
	PROFESSIONAL
}

package fr.dawan.projetLMT.controllers;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import fr.dawan.projetLMT.beans.LocalizeForm;
import fr.dawan.projetLMT.entities.Genre;
import fr.dawan.projetLMT.entities.Instrument;
import fr.dawan.projetLMT.entities.Member;

import fr.dawan.projetLMT.service.GenreService;
import fr.dawan.projetLMT.service.InstrumentService;
import fr.dawan.projetLMT.service.LocalizeService;
import fr.dawan.projetLMT.service.MemberService;

@Controller
@RequestMapping("/localize")
public class LocalizationController {
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	LocalizeService localizeService;
	@Autowired
	private GenreService genreService;
	@Autowired
	private InstrumentService instrumentService;
	
	@GetMapping("/display")
	public String display(Model model) {
		
		List<Genre> listG = genreService.readAll();
		List<Instrument> listInstru = instrumentService.readAll();
		Member exampleMember = memberService.readByEmail("a@a.fr");
		System.out.println(exampleMember);
		model.addAttribute("member",exampleMember);
		model.addAttribute("listInstru", listInstru);
		model.addAttribute("listGenres", listG);
		model.addAttribute("localizeForm",new LocalizeForm());
		return "localizedisplay";
		
	}
	@PostMapping("/filtered")
	public String findFiltered(@ModelAttribute("localizeForm")LocalizeForm localizeForm,BindingResult br,Model model,HttpServletRequest req) {
		List<Member> listMembers =null;
		if("city".equals(localizeForm.getRadiusType())) {
			System.out.println(localizeForm.getMemberCity());
			 listMembers = localizeService.findByCity(localizeForm.getMemberCity());
		}
		else {
			System.out.println(localizeForm.getMemberZipCode());
			listMembers = localizeService.findByZipCode(Integer.parseInt(localizeForm.getMemberZipCode()));
		}
		switch((localizeForm.getSexMember()).toString()) {
			case "M":  listMembers = filtreSex(listMembers, "M");
				break;
			case "F" :listMembers = filtreSex(listMembers, "F");
				break;
			case "OTHER": listMembers = filtreSex(listMembers, "OTHER");
				break;
		}

		List<Instrument> instrus = new ArrayList<Instrument>();
		if (req.getParameterValues("instruments")!=null)
			for (String idInstru : req.getParameterValues("instruments")) {
				Instrument instr = instrumentService.readById((Long.parseLong(idInstru))); // récupérer le genre par son
																							// nom
				instrus.add(instr);
			}
		
		List<Genre> genres = new ArrayList<Genre>();
		if (req.getParameterValues("genres")!=null)
			for (String nom : req.getParameterValues("genres")) {
				Genre genrer = genreService.readByName(nom); // récupérer le genre par son nom
				genres.add(genrer);
			}
		if(!genres.isEmpty())
			listMembers = filtreGenre(listMembers, genres);
		
		if(!instrus.isEmpty())
			listMembers = filtreInstrument(listMembers, instrus);
		
		for (Member member : listMembers) {
			LocalDate birth = member.getBirthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			Period age = Period.between(birth, LocalDate.now());
			member.setAge(age.getYears());
		}
		
		model.addAttribute("listMembres", listMembers);
		return "findMusicians";
	}
	
	
	
	public List<Member> filtreGenre(List<Member> members,List<Genre> genres){
		List<Member> membersFiltered = new ArrayList<Member>();
		List<Genre> genresMember = new ArrayList<Genre>();
		for (Member member :members) {
			for (Genre genre : genres)
				for (Genre genreM : genresMember)
				if (genreM.equals(genre)) 
					membersFiltered.add(member);
				
		}
		return membersFiltered;
	}
	
	public List<Member> filtreInstrument(List<Member> members,List<Instrument> instruments){
		List<Member> membersFiltered = new ArrayList<Member>();
		List<Instrument> instrusMember = new ArrayList<Instrument>();
		for (Member member :members) {
			instrusMember = member.getInstruments();
			for (Instrument instru : instruments)
				for(Instrument instruM : instrusMember)
					if (instruM.equals(instru)) 
						membersFiltered.add(member);
				
		}
		return membersFiltered;
	}
	
	public List<Member> filtreSex(List<Member> members,String sex){
		List<Member> membersFiltered = new ArrayList<Member>();
		for (Member member :members) {
			if (member.getSexMember().toString().equals(sex)) {
				membersFiltered.add(member);
			}
		}
		return membersFiltered;
	}
}

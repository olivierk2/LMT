package fr.dawan.projetLMT.enums;

public enum Sex {
	 M,
	    F,
	    OTHER
}

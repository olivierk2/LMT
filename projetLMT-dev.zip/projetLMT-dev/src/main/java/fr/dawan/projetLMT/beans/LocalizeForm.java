package fr.dawan.projetLMT.beans;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import fr.dawan.projetLMT.entities.Genre;
import fr.dawan.projetLMT.entities.Instrument;
import fr.dawan.projetLMT.entities.Member;
import fr.dawan.projetLMT.enums.Sex;

@Component
public class LocalizeForm implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String radiusType;
	
	private String memberCity;
	
	private String memberZipCode;
	
	private Sex sexMember;
	
	private List<Instrument> instruments;
	
	private List<Genre> genres;
	
	public String getRadiusType() {
		return radiusType;
	}
	public void setRadiusType(String radiusType) {
		this.radiusType = radiusType;
	}

	public Sex getSexMember() {
		return sexMember;
	}
	public void setSexMember(Sex sexMember) {
		this.sexMember = sexMember;
	}
	public List<Instrument> getInstruments() {
		return instruments;
	}
	public void setInstrments(List<Instrument> instruments) {
		this.instruments = instruments;
	}
	public List<Genre> getGenres() {
		return genres;
	}
	public void setGenres(List<Genre> genres) {
		this.genres = genres;
	}

	public String getMemberCity() {
		return memberCity;
	}
	public void setMemberCity(String memberCity) {
		this.memberCity = memberCity;
	}
	public String getMemberZipCode() {
		return memberZipCode;
	}
	public void setMemberZipCode(String memberZipCode) {
		this.memberZipCode = memberZipCode;
	}

	public LocalizeForm() {
		super();
	}
	public LocalizeForm(String radiusType, String memberCity, String memberZipCode, Sex sexMember,
			List<Instrument> instruments, List<Genre> genres) {
		super();
		this.radiusType = radiusType;
		this.memberCity = memberCity;
		this.memberZipCode = memberZipCode;
		this.sexMember = sexMember;
		this.instruments = instruments;
		this.genres = genres;
	}
	
	
}

package fr.dawan.projetLMT.beans;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import fr.dawan.projetLMT.enums.Level;
import fr.dawan.projetLMT.enums.Sex;


@Component
public class MemberForm implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;
	
	@NotNull(message = "Le prénom ne peut pas être vide")
	private String firstname;
	
	@NotNull(message = "Le nom ne peut pas être vide")
	private String lastname;
	
	@NotNull(message = "La date d'anniversaire ne peut pas être vide")
	private String birthday;
	
	private Sex sexMember ;
	
	//pattern="[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$"
	
	@NotNull(message = "L'email ne peut pas être vide")
	@Email(message="Respecter le format pour les emails")
	private String email;
	
	@NotNull(message = "Le mot de passe ne peut pas être vide")
	private String password;
	
	private Level levelMember;
	
	private String adress;
	
	@Digits(fraction = 0, integer = 5)
	@NotNull(message = "Le code postal ne peut pas être vide")
	private String zipCode;
	
	private String city;
	
	private String picture;
	
	private String resume;
	
	private List<String> instruments;
	
	private List<String> genres;
		
	public MemberForm() {
		super();
	}

	public MemberForm(String id, String firstname, String lastname, String birthday, Sex sexMember,
			@NotNull(message = "email vide") @Email(message = "email non valide") String email, String password,
			Level levelMember, String adress, String zipCode, String city, String picture, String resume,
			List<String> instruments, List<String> genres) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.birthday = birthday;
		this.sexMember = sexMember;
		this.email = email;
		this.password = password;
		this.levelMember = levelMember;
		this.adress = adress;
		this.zipCode = zipCode;
		this.city = city;
		this.picture = picture;
		this.resume = resume;
		this.instruments = instruments;
		this.genres = genres;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Sex getSexMember() {
		return sexMember;
	}

	public void setSexMember(Sex sexMember) {
		this.sexMember = sexMember;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Level getLevelMember() {
		return levelMember;
	}

	public void setLevelMember(Level levelMember) {
		this.levelMember = levelMember;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public List<String> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<String> instruments) {
		this.instruments = instruments;
	}

	public List<String> getGenres() {
		return genres;
	}

	public void setGenres(List<String> genres) {
		this.genres = genres;
	}

}

package fr.dawan.projetLMT.entities;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.springframework.format.annotation.DateTimeFormat;

import fr.dawan.projetLMT.enums.Level;
import fr.dawan.projetLMT.enums.Sex;

@Entity
@Table(name="t_member")
public class Member implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Version
	private int version;
	
	private String firstname;
	
	private String lastname;
	
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Temporal(TemporalType.DATE)
	private Date birthday;
	
	private Sex sexMember ;

	@Column(unique = true)
	private String email;
	
	private String password;
	
	private Level levelMember;
	
	private String adress;
	
	private int zipCode;
	
	private String city;
	
	private String picture;
	
	@Transient
	private int age;

	@Column(length = 1000)
	private String resume;
	
	
	@ManyToMany
	private List<Instrument> instruments;	
	
	
	@ManyToMany(fetch = FetchType.EAGER)
	private List<Genre> genres;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<SharedLink> sharedLinks;
	

	public Member() {
		super();
	}


	public Member(int id, int version, String firstname, String lastname, Date birthday, Sex sexMember,

			String email, String password, Level levelMember, String adress, int zipCode, String city, String picture,
			String resume, List<Instrument> instruments, List<Genre> genres, List<SharedLink> sharedLinks) {
		super();
		this.id = id;
		this.version = version;
		this.firstname = firstname;
		this.lastname = lastname;
		this.birthday = birthday;
		this.sexMember = sexMember;
		this.email = email;
		this.password = password;
		this.levelMember = levelMember;
		this.adress = adress;
		this.zipCode = zipCode;
		this.city = city;
		this.picture = picture;
		this.resume = resume;
		this.instruments = instruments;
		this.genres = genres;
		this.sharedLinks = sharedLinks;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public Sex getSexMember() {
		return sexMember;
	}

	public void setSexMember(Sex sexMember) {
		this.sexMember = sexMember;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public List<Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	public List<Genre> getGenres() {
		return genres;
	}

	public void setGenres(List<Genre> genres) {
		this.genres = genres;
	}
	
	public Level getLevelMember() {
		return levelMember;
	}

	public void setLevelMember(Level levelMember) {
		this.levelMember = levelMember;
	}

	public List<SharedLink> getSharedLinks() {
		return sharedLinks;
	}

	public void setSharedLinks(List<SharedLink> sharedLinks) {
		this.sharedLinks = sharedLinks;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
}

package fr.dawan.projetLMT.controllers;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import fr.dawan.projetLMT.beans.MemberForm;
import fr.dawan.projetLMT.entities.FileUploader;
import fr.dawan.projetLMT.entities.Genre;
import fr.dawan.projetLMT.entities.Instrument;
import fr.dawan.projetLMT.entities.Member;
import fr.dawan.projetLMT.service.GenreService;
import fr.dawan.projetLMT.service.InstrumentService;
import fr.dawan.projetLMT.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	@Autowired
	MemberService memberService;
	@Autowired
	private GenreService genreService;
	@Autowired
	private InstrumentService instrumentService;
	@Autowired
	private FileUploader fileUploader;

	@GetMapping("/display")
	public String display(Model model) {

		List<Genre> listG = genreService.readAll();
		List<Member> listU = memberService.readAll();
		List<Instrument> listInstru = instrumentService.readAll();

		model.addAttribute("listMembres", listU);
		model.addAttribute("listGenres", listG);
		model.addAttribute("newMember", new Member());
		model.addAttribute("listInstru", listInstru);
		model.addAttribute("defautltDate", LocalDate.now());

		return "member";
	}

	@RequestMapping(value = "/displayMusicians", method = RequestMethod.GET)
	public String findAllmember(Model model, HttpSession session) {

		List<Member> listMembers = memberService.readAll();

		for (Member member : listMembers) {
			// empecher un nullpointer si la date de naissance n'est pas renseignée
			if(member.getBirthday() != null) {
				LocalDate birth = member.getBirthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

				Period age = Period.between(birth, LocalDate.now());
				member.setAge(age.getYears());
			}
		}

		model.addAttribute("listMembres", listMembers);

		model.addAttribute("firstName", session.getAttribute("sessionfirstName"));

		return "findMusicians";

	}

	@GetMapping("/updateForm")
	public String editProfil(HttpSession session, HttpServletRequest request,Model model) {

		List<Genre> listG = genreService.readAll();

		List<Instrument> listInstru = instrumentService.readAll();
		Member user = (Member) session.getAttribute("user");
		request.setAttribute("listInstruments", listInstru);
		
		model.addAttribute("user", user);

		model.addAttribute("listGenres", listG);

		model.addAttribute("listInstru", listInstru);

		request.setAttribute("listInstruments", listInstru);
		
		return "updateMember";

	}

	
	@PostMapping("/updateMember")
	public String updateMember(@Valid @ModelAttribute("user") Member member, BindingResult br, Model model,
			Locale locale, HttpSession session, HttpServletRequest req) {
				
		List<Instrument> listInstru1=((Member) session.getAttribute("user")).getInstruments();
		System.out.println(listInstru1);
		System.out.println(session.getAttribute("user"));
		// recuperer l'id du membre par la session pour le merge de la requete DAO
		long id=((Member) session.getAttribute("user")).getId();
		
		// creation d'une liste d'instruments si pas d'instruments existants pour le membre
		
	
		if(member.getInstruments() == null || member.getInstruments().isEmpty() )
		{
			
			List<Member> listMember = null;
			listMember.add(member);
			List<Instrument> listInstru = null ;
			Instrument guitare=new Instrument(0 ,0,"basse", listMember);
			listInstru.add(guitare);
			((Member) session.getAttribute("user")).setInstruments(listInstru);
			
		}
		
		member.setId(id);
		System.out.println("id"+id);
	
		memberService.update(member);
		return "/displayMusicians";
	}

	// read by id
	@GetMapping("/readById/{id}")
	public Object readById(@PathVariable("id") long id, Model model) {
		Member mId = memberService.readById(id);
		System.out.println(mId);

		return display(model);
	}

	@PostMapping("/newMember")
	public String createMember(@Valid @ModelAttribute("newMember") MemberForm member,BindingResult br, Model model, HttpSession session) {

		Member newMember = new Member();

		// Si il y a des erreurs de validation
		if(br.hasErrors()) {
			return "member";
		}

		// Si l'email existe déjà en base (les emails doivent être uniques)
		if(memberService.readByEmail(member.getEmail()) != null) {
			model.addAttribute("msg", "Echec de la création : l'email renseigné est déjà utilisé, veuillez en utiliser un autre.");
			return display(model);
		}

		if(member.getBirthday() == null ) {
			newMember.setBirthday(new Date());
		} else {
			try {
				newMember.setBirthday(new SimpleDateFormat("dd-MM-yyyy").parse(member.getBirthday()));
			} catch (ParseException e) {
				newMember.setBirthday(new Date());
			}
		}

		List<Instrument> instrus = new ArrayList<Instrument>();

		for(String idInstru : member.getInstruments()) {

			Instrument instr = instrumentService.readById((Long.parseLong(idInstru))); 
			instrus.add(instr);
		}

		newMember.setInstruments(instrus);

		// Recuperation des genres
		List<Genre> genres = new ArrayList<Genre>();

		for (String id : member.getGenres()) {
			Genre genre = genreService.readById((Long.parseLong(id))); 
			genres.add(genre);
		}

		newMember.setGenres(genres);

		newMember.setAdress(member.getAdress());
		newMember.setCity(member.getCity());
		newMember.setEmail(member.getEmail());
		newMember.setFirstname(member.getFirstname());
		newMember.setLastname(member.getLastname());
		newMember.setLevelMember(member.getLevelMember());
		newMember.setPassword(member.getPassword());
		newMember.setPicture(member.getPicture());
		newMember.setResume(member.getResume());
		newMember.setSexMember(member.getSexMember());
		newMember.setZipCode(Integer.parseInt(member.getZipCode()));

		memberService.create(newMember);
		model.addAttribute("msg", "Enregistrement du nouveau compte pour " + member.getFirstname() + " terminé");

		session.setAttribute("emailNewMember", member.getEmail());

		return "home";
	}

//	@PostMapping("/updateMember")	
//	public String UpdateMember(@Valid @ModelAttribute("newMember") Member member,BindingResult br, Model model,
//			Locale locale, HttpSession session, HttpServletRequest req) {	
//
//		System.out.println("user"+member.getId());
//		model.addAttribute("id", member.getId());
//		memberService.update(member);
//		return "/displayMusicians";
//	}

	@PostMapping("/import")
	public String importPhoto(Model model, /*BindingResult result,*/
			@RequestParam("photo") MultipartFile file, HttpServletRequest request, HttpSession session) {
		String picture="../../";
		// On récupère l'email du dernier membre nouvellement créé qui a été stocké en session lors de la création
		Member member = memberService.readByEmail((String)session.getAttribute("emailNewMember"));

		if (!file.isEmpty()) {
			try {
				picture=   fileUploader.uploadFile(file,String.valueOf(member.getId()), request);
			} catch (IOException e) {
				model.addAttribute("msgPhoto", "Erreur lors du chargement de l'image.");
			}
		} else {
			model.addAttribute("msgPhoto", "Image introuvable.");
		}

		member.setPicture(picture);
		memberService.update(member);
		model.addAttribute("msgPhoto", "Image enregistrée.");
		return display(model);
	}

	@ModelAttribute("newMember")
	public MemberForm getUserForm() {
		return new MemberForm();
	}
	@RequestMapping("/sessionOut")
	public String CloseSession(HttpSession session) {
		session.invalidate();

		return "home";
	}
}

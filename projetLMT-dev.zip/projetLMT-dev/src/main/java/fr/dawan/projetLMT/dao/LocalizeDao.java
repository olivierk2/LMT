package fr.dawan.projetLMT.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import fr.dawan.projetLMT.entities.Member;

@Repository
public class LocalizeDao{
	
	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<Member> readByCity(String city){
		try {
			return em.createQuery("From Member m JOIN FETCH m.instruments WHERE m.city= :city").setParameter("city", city).getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}	
		
	}

	public List<Member> readByZipCode(int zipcode) {
		try {
			int tempzip = zipcode/1000; 
			System.out.println(tempzip);
			return em.createQuery("From Member m JOIN FETCH m.instruments WHERE m.zipCode LIKE concat(:tempzip, '%')").setParameter("tempzip", tempzip).getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	
}




































































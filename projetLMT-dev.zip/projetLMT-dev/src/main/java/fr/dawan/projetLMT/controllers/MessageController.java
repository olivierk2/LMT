package fr.dawan.projetLMT.controllers;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import fr.dawan.projetLMT.beans.MessageForm;
import fr.dawan.projetLMT.entities.Member;
/*import fr.dawan.projetLMT.entities.Member;*/
import fr.dawan.projetLMT.entities.Message;
import fr.dawan.projetLMT.service.MemberService;
import fr.dawan.projetLMT.service.MessageService;
/*import fr.dawan.spring.beans.UserManagementForm;
import fr.dawan.spring.entities.User;*/
/*import fr.dawan.spring.beans.UserManagementForm;*/



@Controller 
@RequestMapping("/message")
public class MessageController {
  	
	@Autowired
	private MessageService messageService; 
	
	@Autowired
	private MemberService memberService; 
	
	@GetMapping("/display")
	public String display(Model model) {

		List<Message> messages = messageService.readAll();
		model.addAttribute("messagesList", messages);

		Date a = new Date(); // this object contains the current date value
		/* LocalDate a = LocalDate.now(); */

		model.addAttribute("today", a);

		return "message";
	}
	
	@GetMapping("/delete/{ligneId}")
	public String deleteMessage(@PathVariable("ligneId") String id, Model model) {
		
		messageService.delete(Long.parseLong(id));
		
		return display(model);
	}
	
	@GetMapping("/displaymessage/{ligneId}")
	public String displayMessage(@PathVariable("ligneId") String id, Model model) {
		
		Message m = messageService.readById(Long.parseLong(id)); 
	    model.addAttribute("messagetodisplay", m); 			
	    
		return "displaymessage";
		}
		
			
	@PostMapping("/create")
	public String createMessage(@Valid @ModelAttribute("messageManagementForm") MessageForm msgForm, BindingResult br,
			Model model, Locale locale, HttpSession session) {

		// Vérification du résultat de la validation
		/*
		 * if (br.hasErrors()) {
		 * 
		 * return "inserted"; }
		 */

		// Cas de création car l'id n'est pas renseigné
		/* if (msgForm.getId() == null) { */

		
		Member s = memberService.readById(Long.parseLong(msgForm.getSender()));
		  
		Member r = memberService.readById(Long.parseLong(msgForm.getReciever()));
		
		/*
		 * LocalDateTime currentTime = LocalDateTime.now(); LocalDate d =
		 * currentTime.toLocalDate();
		 */
		
		/* Date d = Date.now(); */
		Date d = new Date(); // this object contains the current date value
		String msg; 
		 
		if (r == null) {
			msg = "The receiver Id: (" + msgForm.getReciever() + ") does not exist";
		} else {

			Message m = new Message(0, 0, msgForm.getContent(), d, s, r);
			messageService.create(m);
			msg = "message sent";
		}
			
		// }
		// Cas de la modification car l'id sera tjrs renseigné
		/*
		 * else { User u = new User(Long.parseLong(userForm.getId()),
		 * Integer.parseInt(userForm.getVersion()), userForm.getNom(),
		 * userForm.getEmail(), userForm.getPassword());
		 * 
		 * userService.update(u); }
		 */
 		model.addAttribute("errors",msg);
 		model.addAttribute("today1",d); 
		return display(model);
	}
	
	// Injecte automatiquement le bean userManagementForm dans le model à chaque
		// nouvelle requête
		@ModelAttribute("messageManagementForm")
		public MessageForm getUserManagementForm() {
			return new MessageForm();
		}

}

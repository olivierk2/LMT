package fr.dawan.projetLMT.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import fr.dawan.projetLMT.entities.Message;
/*import fr.dawan.spring.entities.User;*/
/*import fr.dawan.spring.entities.User;*/

@Repository
public class MessageDao {
	
	@PersistenceContext 
	private EntityManager em;


	@SuppressWarnings("unchecked")
	public List<Message> readAll() {
		try {
			return em.createQuery("From Message").getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	 
	public void delete(Message message) {
		try {
			em.remove(message);
		}catch(Exception e) {
			e.printStackTrace();
		}
	} 
	
	public Message readById(long id) {
		try {
			// User u = (User) em.createQuery("From User WHERE id= :id").setParameter("id",
			// id).getSingleResult();
			return (Message) em.createQuery("From Message WHERE id= :id").setParameter("id", id).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void create(Message message) {
		try {
			em.persist(message);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/*
	 * public void delete(Message message) { try { em.remove(message);
	 * }catch(Exception e) { e.printStackTrace(); } }
	 */
	
	
	
	
}

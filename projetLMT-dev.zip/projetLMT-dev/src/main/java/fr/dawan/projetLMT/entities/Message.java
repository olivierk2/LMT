package fr.dawan.projetLMT.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

@Entity
@Table(name="t_message")
public class Message implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Version
	private int version;
	
	@Column(length = 1000)
	private String content;
		
	@Temporal(TemporalType.DATE)
	private Date dateMessage;
	
	@ManyToOne
	private Member sender;
	
	@ManyToOne
	private Member reciever;

	public Message() {
		super();
	}

	public Message(long id, int version, String content, Date dateMessage) {
		super();
		this.id = id;
		this.version = version;
		this.content = content;
		this.dateMessage = dateMessage;
	}

	public long getId() {
		return id;
	}

	public Member getSender() {
		return sender;
	}


	public Message(long id, int version, String content, Date dateMessage, Member sender, Member reciever) {
		super();
		this.id = id;
		this.version = version;
		this.content = content;
		this.dateMessage = dateMessage;
		this.sender = sender;
		this.reciever = reciever;
	}

	public void setSender(Member sender) {
		this.sender = sender;
	}

	public Member getReciever() {
		return reciever;
	}

	public void setReciever(Member reciever) {
		this.reciever = reciever;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getDateMessage() {
		return dateMessage;
	}

	public void setDateMessage(Date dateMessage) {
		this.dateMessage = dateMessage;
	}



}

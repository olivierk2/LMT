package fr.dawan.projetLMT.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.dawan.projetLMT.dao.MessageDao;
import fr.dawan.projetLMT.entities.Message;
/*import fr.dawan.spring.entities.User;*/
/*import fr.dawan.spring.entities.User;*/

@Service
public class MessageService {
	
	@Autowired
	private MessageDao messageDao;
	 	
	@Transactional
	public List<Message> readAll() {
		return messageDao.readAll();
	}

	@Transactional
	public void delete(long id) {
		Message m = readById(id);
		messageDao.delete(m);
	}
	
	@Transactional
	public Message readById(long id) {
		return messageDao.readById(id);
	}
	
	@Transactional //  Annotation qui permet de gérer les flux de connexions (ouverture, fermeture et rollback en cas d'erreur sur la requête)
	public void create(Message message) {
		// Si modification à faire sur le user les faire ici SURTOUT avant l'appel du dao
		messageDao.create(message);
	}
	
	
}
